public class Computer extends App {
    int compScore = 0;


}
