public class User extends App {

    private String name;
    int userScore = 0;


    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
